import './App.css';
import LoginForm from "./LoginForm";
function App() {
  return (
    <div className="main">
     <LoginForm /> 
    </div>
  );
}

export default App;
